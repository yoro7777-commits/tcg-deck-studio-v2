# TCG Deck Studio 1.0.0

Android用のデッキ作成アプリです。ラブカ、ポケカ、ユニアリを切り替え、カード検索、最大5デッキ保存、枚数・同名カード制限、JSON入出力を利用できます。

## APKを作る

GitHubへこのフォルダを置くと、Actionsの `Build Android APK` が自動実行されます。完了後、Artifactsの `TCG-Deck-Studio-debug-apk` をダウンロードしてください。

ローカルにAndroid SDKとGradle 8.10.2がある場合は `gradle assembleDebug` でも作成できます。

## 注意

- ポケカ検索はTCGdexの日本語APIを利用します。
- アプリが生成するレシピコードはTCG Deck Studio独自形式で、公式デッキコードではありません。
- 大会前は公式の最新レギュレーション・禁止制限を確認してください。
