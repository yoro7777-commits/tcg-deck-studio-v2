# WebView-only app. Keep the default Android rules.

