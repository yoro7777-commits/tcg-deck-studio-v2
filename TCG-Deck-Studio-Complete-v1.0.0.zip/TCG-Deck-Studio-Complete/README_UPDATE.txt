TCG Deck Studio v5 完成版 更新パック

追加・更新内容
- ご指定のTCG Deck Studio画像をホーム画面に採用
- その画像の左上デザインをAndroidランチャーアイコンとして加工・追加
- Android用アイコンを mdpi / hdpi / xhdpi / xxhdpi / xxxhdpi に同梱
- AndroidManifest.xml に icon / roundIcon を設定
- ライト / ダーク / 端末設定連動を搭載
- ラブカ / ポケカ / UNION ARENA の3タイトル切替
- カード検索、タイプ/シリーズ/レアリティ絞り込み
- カード画像表示
- 各TCG 最大5デッキ保存
- レシピ書き出し・コピー
- JSONカードデータ取り込み/書き出し
- ゲーム別デッキ枚数チェック

GitHubに上書きする主な場所
src/main/assets/index.html
src/main/assets/tcg_deck_studio_promo.png
src/main/res/values/styles.xml
src/main/res/mipmap-*/ic_launcher.png
src/main/res/mipmap-*/ic_launcher_round.png
src/main/AndroidManifest.xml

既存の build-apk.yml が src/** の変更を検知するため、mainへコミット後にGitHub Actionsが自動再ビルドします。
